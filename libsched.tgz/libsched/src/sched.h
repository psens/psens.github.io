/*
 * sched.h
 *
 * Copyright (C) 2001  Pierre Sens (Pierre.Sens@lip6.fr)
 *
 * Mini-ordonnanceur de fonctions utilisateurs
 *
 * Ported to GCC 15:
 *   - function_t prototype rendu explicite (void)
 *   - Encodage converti en UTF-8
 */
#ifndef _SCHED_H_
#define _SCHED_H_

#include <sys/time.h>
#include <setjmp.h>
#include <signal.h>

#define true  1
#define false 0
#define main  MAIN

/* Parametres de l'ordonnanceur */
#define QUANTUM   1

/* Types d'ordonnancement */
#define NEW       1    /* Nouvelle strategie definie par l'utilisateur */
#define PREMPT    2    /* Ordonnancement preemptif */
#define BATCH     3    /* Ordonnancement de type Batch */

#define MAXPROC   20   /* Nombre maximum de processus */

#define MINPRIO   0
#define MAXPRIO   100

/* Etat d'un processus */
#define RUN  1
#define IDLE 2
#define ZOMB 3

/*
 * function_t : prototype explicite (void) pour eviter le warning
 * "function declaration isn't a prototype" en C17/C23.
 */
typedef void (*function_t)(void *);

typedef struct proc {
    int         flag;               /* Etat de la tache */
    int         prio;               /* Priorite */
    int         pid;                /* Pid */
    sigjmp_buf  env;                /* Contexte materiel (registres) */
    function_t  func;               /* Le code */
    void       *arg;                /* Les arguments */
    int         stack_size;         /* Taille de la pile d'execution */
    char       *stack_svg;          /* La pile */
    struct timeval end_time;        /* Date de fin */
    struct timeval start_time;      /* Date de creation */
    struct timeval realstart_time;  /* Date de lancement */
    double      ncpu;               /* CPU consommes */
    double      duration;           /* Temps estime de la tache */
} proc_t;

extern struct proc Tproc[MAXPROC];

void sched(int printmode);
int  CreateProc(function_t, void *, int);
void SchedParam(int type, double quantum, int (*f)(void));
void PrintStat(void);
int  GetElecProc(void);

#endif /* _SCHED_H_ */
