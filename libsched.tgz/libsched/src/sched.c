/*
 * sched.c
 *
 * Copyright (C) 2001  Pierre Sens (Pierre.Sens@lip6.fr)
 *
 * Mini-ordonnanceur de fonctions utilisateurs
 *
 * Ported to GCC 15 / glibc 2.40+:
 *   - bcopy()    -> memmove()
 *   - <malloc.h> -> <stdlib.h>  (deja inclus via sched.h)
 *   - sa_handler cast corrige via un wrapper conforme POSIX
 *   - setjmp/longjmp uniformises en sigsetjmp/siglongjmp
 *   - function_t prototype rendu explicite (void)
 *   - Encodage source converti en UTF-8
 */

#define _GNU_SOURCE
#include <dlfcn.h>

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <setjmp.h>
#include <signal.h>

#include "sched.h"

#define REEVAL 5
#define DEBUG printf

#undef main

struct proc Tproc[MAXPROC];

static sigjmp_buf envsched;
static long base;

static double Quantum = QUANTUM;
static int commut(int s);
static int election(void);
static void InitSched(void);
static void AjustPrio(void);
static int (*felect)(void) = election;
static int verbose;

static int courant;         /* Indice du processus elu */
static int nbrun;           /* Nombre de processus prets */
static int pidcount = 0;    /* Compteur pour generer les pid */
static sigset_t mask;

int MAIN(int, char **);

/* ------------------------------------------------------------------ */
/* Wrapper conforme POSIX pour sa_handler (void (*)(int))              */
/* commut() retourne int mais sa_handler attend void (*)(int).         */
/* Le wrapper absorbe la valeur de retour.                             */
/* ------------------------------------------------------------------ */
static void commut_handler(int s)
{
    (void) commut(s);
}

/* Retourne le processus elu ou -1 s'il n'y en a aucun */
int GetElecProc(void) {
    return (Tproc[courant].flag == RUN) ? courant : -1;
}

/* ------------------------------------------------------------------ */
/* Fonction appelee toutes les "Quantum" secondes : commutation        */
/* ------------------------------------------------------------------ */
int commut(int s) {
    int top;
    int ssize, k;
    (void) s;   /* parametre requis par le prototype de signal handler */

    if (verbose)
        DEBUG("Commutation !\n");

    if (courant < 0 || courant >= MAXPROC || nbrun == 0)
        return 0;

    if (verbose) {
        for (k = 0; k < MAXPROC; k++)
            if (Tproc[k].flag == RUN)
                DEBUG(" <%d,%d>", k, Tproc[k].prio);
        DEBUG("\n");
    }

    /* Sauvegarde de la pile */
    ssize = (int)(base - (unsigned long) &top);

    if (Tproc[courant].stack_svg == NULL) {
        if ((Tproc[courant].stack_svg = (char *) malloc((size_t)ssize)) == NULL) {
            perror("sched - malloc");
            exit(1);
        }
    } else if (ssize > Tproc[courant].stack_size) {
        if ((Tproc[courant].stack_svg =
                (char *) realloc(Tproc[courant].stack_svg, (size_t)ssize)) == NULL) {
            perror("sched - realloc");
            exit(1);
        }
    }

    Tproc[courant].stack_size = ssize;

    /* bcopy() supprime -> memmove() */
    memmove(Tproc[courant].stack_svg, (char *) &top,
            (size_t)(base - (unsigned long) &top));

    if (sigsetjmp(Tproc[courant].env, 1) == 0) {
        Tproc[courant].ncpu += Quantum;
        /* Commutation */
        siglongjmp(envsched, 0);
    } else {
        /* Restauration de la pile */
        memmove((char *) base - Tproc[courant].stack_size,
                Tproc[courant].stack_svg,
                (size_t)Tproc[courant].stack_size);
    }
    return 0;
}

/* ------------------------------------------------------------------ */
/* Reevaluation des priorites toutes les REEVAL secondes              */
/* ------------------------------------------------------------------ */
void AjustPrio(void) {
    int i;
    for (i = 0; i < MAXPROC; i++) {
        if (Tproc[i].func != NULL) {
            Tproc[i].prio += REEVAL / 2;
            if (Tproc[i].prio > MAXPRIO)
                Tproc[i].prio = MAXPRIO;
        }
    }
}

/* Election par defaut : priorite dynamique + reevaluation */
int election(void) {
    static unsigned int i = 0;
    static int cpt = 0;
    unsigned int j;
    int p;
    int maxprio = MINPRIO;
    int elu = GetElecProc();

    cpt++;
    if (cpt == REEVAL) {
        if (verbose) DEBUG("REEVALUATION\n");
        AjustPrio();
        cpt = 0;
    }

    if (Tproc[elu].prio > MINPRIO) Tproc[elu].prio--;

    p = 0;
    j = (i - 1) % MAXPROC;

    for (; i != j; i = (i + 1) % MAXPROC) {
        if (Tproc[i].flag == RUN && Tproc[i].prio > maxprio) {
            maxprio = Tproc[i].prio;
            p = i;
        }
    }
    return p;
}

/* Fixer les parametres de l'ordonnanceur */
void SchedParam(int type, double timeslice, int (*elec)(void)) {
    switch (type) {
    case BATCH:
        Quantum = 0;
        break;
    case PREMPT:
        Quantum = timeslice;
        break;
    case NEW:
        felect = elec;
        Quantum = timeslice;
        break;
    }
}

/* ------------------------------------------------------------------ */
/* Boucle de l'ordonnanceur                                            */
/* ------------------------------------------------------------------ */
void sched(int print) {
    struct sigaction sa;
    sigset_t m;
    struct itimerval timer;

    verbose = print;

    sigemptyset(&m);
    /* Utilisation du wrapper void(*)(int) : plus de cast invalide */
    sa.sa_handler = commut_handler;
    sa.sa_flags   = SA_NODEFER;
    sa.sa_mask    = m;

    sigaction(SIGALRM, &sa, NULL);

    sigsetjmp(envsched, 1);

    timer.it_value.tv_sec  = (long) Quantum;
    timer.it_value.tv_usec = (long)(1e6 * ((double) Quantum - (double) timer.it_value.tv_sec));
    timer.it_interval.tv_sec  = (long) Quantum;
    timer.it_interval.tv_usec = (long)(1e6 * ((double) Quantum - (double) timer.it_value.tv_sec));
    setitimer(ITIMER_REAL, &timer, NULL);

    if (nbrun != 0) {
        courant = felect();
        if (courant >= 0 && courant < MAXPROC && Tproc[courant].flag == RUN) {
            siglongjmp(Tproc[courant].env, 0);
        } else {
            printf("Error: election of a wrong task - task id = %d\n", courant);
            exit(1);
        }
    }
}

/* ------------------------------------------------------------------ */
/* Creer une nouvelle tache                                            */
/* ------------------------------------------------------------------ */
int CreateProc(function_t f, void *arg, int d) {
    int ret;
    int i = 0;

    while (i < MAXPROC && Tproc[i].flag != IDLE)
        i++;
    if (i == MAXPROC)
        return -1;

    Tproc[i].flag     = RUN;
    Tproc[i].pid      = pidcount++;
    Tproc[i].func     = f;
    Tproc[i].arg      = arg;
    Tproc[i].ncpu     = 0;
    Tproc[i].duration = d;
    Tproc[i].prio     = MAXPRIO;
    gettimeofday(&Tproc[i].start_time, NULL);

    nbrun++;

    /* Uniformisation : sigsetjmp comme partout ailleurs */
    if ((ret = sigsetjmp(Tproc[i].env, 1)) == 0)
        return 0;
    else {
        (void) ret;

        if (Quantum == 0)
            gettimeofday(&Tproc[courant].realstart_time, NULL);

        /* Lancement de la fonction */
        Tproc[courant].func(Tproc[courant].arg);

        /* Statistiques CPU */
        gettimeofday(&Tproc[courant].end_time, NULL);

        if (Quantum == 0) {
            Tproc[courant].ncpu =
                (double)(Tproc[courant].end_time.tv_sec  - Tproc[courant].realstart_time.tv_sec) +
                (double)(Tproc[courant].end_time.tv_usec - Tproc[courant].realstart_time.tv_usec) * 1e-6;
        } else {
            struct itimerval itimer;
            getitimer(ITIMER_REAL, &itimer);
            Tproc[courant].ncpu +=
                (double) Quantum -
                ((double) itimer.it_value.tv_sec + (double) itimer.it_value.tv_usec * 1e-6);
        }

        free(Tproc[courant].stack_svg);
        Tproc[courant].stack_svg = NULL;
        Tproc[courant].flag = ZOMB;
        nbrun--;

        /* Uniformisation : siglongjmp vers un sigjmp_buf */
        siglongjmp(envsched, 0);
    }

    /* Jamais atteint, mais evite un warning de retour manquant */
    return 0;
}

/* Initialisation de la table des processus */
void InitSched(void) {
    int i;
    for (i = 0; i < MAXPROC; i++) {
        Tproc[i].start_time.tv_sec      = 0;
        Tproc[i].start_time.tv_usec     = 0;
        Tproc[i].realstart_time.tv_sec  = 0;
        Tproc[i].realstart_time.tv_usec = 0;
        Tproc[i].end_time.tv_sec        = 0;
        Tproc[i].end_time.tv_usec       = 0;
        Tproc[i].flag = IDLE;
        Tproc[i].func = NULL;
        Tproc[i].stack_svg = NULL;
        Tproc[i].stack_size = 0;
    }
    sigemptyset(&mask);
    sigaddset(&mask, SIGALRM);
}

/* Affiche les statistiques de toutes les taches */
void PrintStat(void) {
    int i, j;
    double t, avg_rt, avg_ct;

    sigprocmask(SIG_BLOCK, &mask, NULL);

    j = 0;
    avg_rt = avg_ct = 0.0;

    printf("PID\tFUNCTION\tREAL-TIME\tCPU-TIME\tWAITING-TIME\n");
    printf("--------------------------------------------------------------------\n");

    for (i = 0; i < MAXPROC; i++) {
        if (Tproc[i].flag != IDLE) {
            Dl_info info;

            /*
             * dladdr() attend un void*, mais un pointeur de fonction
             * n'est pas directement convertible en void* en C strict.
             * On utilise memcpy pour copier les bits sans UB,
             * et on supprime le warning pedantic residuel avec un pragma.
             */
            {
                void *fptr;
                function_t tmp = Tproc[i].func;
                memcpy(&fptr, &tmp, sizeof(fptr));
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpedantic"
            if (!dladdr(fptr, &info)) {
#pragma GCC diagnostic pop
                fprintf(stderr, "Unknown function\n");
                exit(1);
            }

            } /* fin du bloc fptr */
            t = (double)(Tproc[i].end_time.tv_sec  - Tproc[i].start_time.tv_sec) +
                (double)(Tproc[i].end_time.tv_usec - Tproc[i].start_time.tv_usec) * 1e-6;
            if (t < 0) t = 0;

            printf("%d\t%s\t%02.3fs\t\t%2.3fs\t\t%2.3fs\n",
                   i, info.dli_sname, t, Tproc[i].ncpu, t - Tproc[i].ncpu);
            avg_rt += t;
            avg_ct += Tproc[i].ncpu;
            j++;

            if (Tproc[i].flag == ZOMB) {
                Tproc[i].flag = IDLE;
                Tproc[i].func = NULL;
            }
        }
    }

    printf("--------------------------------------------------------------------\n");
    if (j > 0)
        printf("Average:\t\t%2.3fs\t\t%2.3fs\t\t%2.3fs\n",
               avg_rt / (double)j, avg_ct / (double)j,
               (avg_rt - avg_ct) / (double)j);
    printf("--------------------------------------------------------------------\n");

    sigprocmask(SIG_UNBLOCK, &mask, NULL);
}

/* Le "vrai" main */
int main(int argc, char *argv[]) {
    int ret;
    int i;
    base = (long) &i;

    setbuf(stdout, NULL);
    InitSched();
    ret = MAIN(argc, argv);
    exit(ret);
}
