/* main.c - Exemple d'utilisation du sémaphore et mémoire partagée */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <semaphore_dijkstra.h>

#define NCHILD 4

/* Définition de la mémoire partagée */
typedef struct {
    int counter;
    char flag;
} shared_data_t;

static dijkstra_shm_t shm;
static shared_data_t *shared;

/* Définition des sémaphores */

static dijkstra_sem_t semB[NCHILD]; /* Pour bloquer les fils */
static dijkstra_sem_t mutex; /* Pour l'accès à la mémoire partagé en SC */


/* Code des processus fils */

void child(int id) {
  printf("Début processus %d\n", id);
  
  /* Attendre que le procesus main reveille */
  P(&semB[id]);

  /* Accéder aux variables partagées en mutex */
  P(&mutex);
  shared->counter++;
  shared->flag += id;
  V(&mutex);

  printf("Fin processus %d\n", id);
  exit(0);
}
  
void destroy_sem() {
  for (int i  = 0; i < NCHILD; i++) 
    sem_destroy_dijkstra(&semB[i]);
  sem_destroy_dijkstra(&mutex);
}

int main(void) {

  /* Initialisation des sémaphores */

  for (int i=0; i < NCHILD; i++) {
    if (sem_init_dijkstra(&semB[i], 0)) {
      perror("sem_init_dijkstra");
      return 1;
    }
  }
  
  if (sem_init_dijkstra(&mutex, 1)) {
    perror("sem_init_dijkstra");
    return 1;
  }
  
  /* Création de la mémoire partagée */
  if (shm_init_dijkstra(&shm, sizeof(shared_data_t))) {
    perror("shm_init_dijkstra");
    destroy_sem();
    return 1;
  }

  shared = (shared_data_t*)shm.ptr;

  /* Initialisation de la mémoire partagée */
  shared->counter = 0;
  shared->flag = 'A';

  /* Création des processus fils */
  for (int i = 0; i < NCHILD; ++i) {
    pid_t pid = fork();
    if (pid < 0) {
      perror("fork");
      exit(1);
    }
    if (pid == 0) {
      child(i);
    }
  }

  
  /* Reveiller les fils */
  for (int i = 0; i < NCHILD; ++i) 
    V(&semB[i]);
  
  /* Attendre tous les fils */
  for (int i = 0; i < NCHILD; ++i)
    wait(NULL);

  printf("Tous les processus  terminés, counter final = %d, flag final = %c\n", shared->counter, shared->flag);

  /* Destruction */
  shm_destroy_dijkstra(&shm);
  destroy_sem();

  return 0;
}
