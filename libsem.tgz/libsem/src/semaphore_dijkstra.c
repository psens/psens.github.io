/* semaphore_dijkstra.c */
#include "semaphore_dijkstra.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>

/* ---------------- Sémaphore ---------------- */
int sem_init_dijkstra(dijkstra_sem_t *s, unsigned int val) {
    if (!s) return EINVAL;
    pid_t pid = getpid();
    static int count = 0;
    unsigned int r = (unsigned int)time(NULL) ^ (unsigned int)count;
    count++;
    snprintf(s->name, sizeof(s->name), "/sem_dijkstra_%d_%u", pid, r);
    s->sem = sem_open(s->name, O_CREAT | O_EXCL, 0600, val);
    if (s->sem == SEM_FAILED) return errno;
    return 0;
}

int P(dijkstra_sem_t *s) {
    if (!s || !s->sem) return EINVAL;
    int r;
    do { r = sem_wait(s->sem); } while (r == -1 && errno == EINTR);
    return r == 0 ? 0 : errno;
}

int V(dijkstra_sem_t *s) {
    if (!s || !s->sem) return EINVAL;
    int r = sem_post(s->sem);
    return r == 0 ? 0 : errno;
}

int sem_destroy_dijkstra(dijkstra_sem_t *s) {
    if (!s || !s->sem) return EINVAL;
    int r1 = sem_close(s->sem);
    int r2 = sem_unlink(s->name);
    s->sem = NULL;
    return r1 ? r1 : r2;
}

/* ---------------- Mémoire partagée ---------------- */
int shm_init_dijkstra(dijkstra_shm_t *shm, size_t size) {
    if (!shm || size == 0) return EINVAL;
    pid_t pid = getpid();
    unsigned int r = (unsigned int)time(NULL) ^ (unsigned int)pid;
    snprintf(shm->name, sizeof(shm->name), "/shm_dijkstra_%d_%u", pid, r);

    shm->fd = shm_open(shm->name, O_CREAT | O_EXCL | O_RDWR, 0600);
    if (shm->fd == -1) return errno;

    if (ftruncate(shm->fd, size) == -1) {
        int e = errno;
        close(shm->fd);
        shm_unlink(shm->name);
        return e;
    }

    void *ptr = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, shm->fd, 0);
    if (ptr == MAP_FAILED) {
        int e = errno;
        close(shm->fd);
        shm_unlink(shm->name);
        return e;
    }

    shm->ptr = ptr;
    shm->size = size;
    return 0;
}

int shm_destroy_dijkstra(dijkstra_shm_t *shm) {
    if (!shm || !shm->ptr) return EINVAL;
    int r1 = munmap(shm->ptr, shm->size);
    int r2 = close(shm->fd);
    int r3 = shm_unlink(shm->name);
    shm->ptr = NULL;
    return r1 ? r1 : (r2 ? r2 : r3);
}
