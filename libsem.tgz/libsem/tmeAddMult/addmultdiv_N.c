/*
 * addmult_N_corrige.c
 *
 * Corrigé N variables
 *
 * Synchronisation déterministe par variable.
 *
 * Chaque variable possède :
 *
 *   - son mutex
 *   - ses compteurs
 *   - ses barrières Add/Mult
 *
 */

#define _DEFAULT_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>



#include "semaphore_dijkstra.h"

#define NADD      5
#define NMULT     5
#define NB_VAR    10
#define NB_TOURS  10


#define RED   "\033[31m"
#define GREEN "\033[32m"
#define RESET "\033[0m"

/*------------------------------------------------------------------*/
/* Données partagées                                                */
/*------------------------------------------------------------------*/

typedef struct
{
    long result[NB_VAR];

  /* A COMPLETER */

} shared_data_t;

/*------------------------------------------------------------------*/

static dijkstra_shm_t shm;
static shared_data_t *shared;

/*------------------------------------------------------------------*/
/* Définition des sémaphores                                        */
/*------------------------------------------------------------------*/


/*
 * A COMPLETER
 */


static int calcul_add(int id)
{
  return id + 1;
}

static int calcul_mult()
{
  return 2;
}

static int calcul_div()
{
  return 3;
}

static long check(int i)
{ int k;
  int inc = NADD*(NADD+1)/2;
  long res = i;

  for (k=0; k < NB_TOURS; k++) {
    res += inc;
    res *= 1<<NMULT;
    res /= 3;
  }
  return res; 
}


/*------------------------------------------------------------------*/
/* Processus Add                                                    */
/*------------------------------------------------------------------*/

void add_process(int id) {
  int v = 0;

  for(int tour=0 ; tour<NB_TOURS*NB_VAR ; tour++)
    {
      
      /* A COMPLETER */
      
      int valeur = calcul_add(id);
      
      usleep(rand()%5000);
      
      /* mettre à jour la variable v */

      shared->result[v] += valeur;

      v = (v + 1) % NB_VAR;
    }

    exit(EXIT_SUCCESS);
}


/*------------------------------------------------------------------*/
/* Processus Mult                                                   */
/*------------------------------------------------------------------*/

void mult_process(int id) {

  int v = 0;
  for(int tour=0 ; tour<NB_TOURS*NB_VAR ; tour++) {


    /* A COMPLETER */

    /* Calcul local */

    int facteur = calcul_mult(id);

    usleep(rand()%5000);

    /* Mise à jour de la variable */

    shared->result[v] *= facteur;

    v = (v + 1) % NB_VAR;
  }

  exit(EXIT_SUCCESS);
}


/*------------------------------------------------------------------*/
/* Processus Div                                                    */
/*------------------------------------------------------------------*/

void div_process() {
  int v = 0;
  for(int tour=0 ; tour<NB_TOURS*NB_VAR ; tour++) {

    /* A COMPLETER */

    /* Calcul local */

    int diviseur = calcul_div();
    
    usleep(rand()%5000);

    /* Mise à jour de la variable */
    
    shared->result[v] /= diviseur;

  }
  
  exit(EXIT_SUCCESS);

}

/*------------------------------------------------------------------*/

static void init_shared_data(void)
{
  for(int i=0 ; i<NB_VAR ; i++){
    shared->result[i] = i;
  }
    /* A COMPLETER */
}

/*------------------------------------------------------------------*/

static void init_semaphores(void)
{

  /* A COMPLETER */
    
}

/*------------------------------------------------------------------*/

static void destroy_semaphores(void)
{

  /* A COMPLETER */
  
}

/*------------------------------------------------------------------*/

static void create_add_processes(void)
{
    for(int i=0 ; i<NADD ; i++)
    {
        pid_t pid = fork();

        if(pid < 0)
        {
            perror("fork");
            exit(EXIT_FAILURE);
        }

        if(pid == 0)
        {
            add_process(i);
        }
    }
}

/*------------------------------------------------------------------*/

static void create_mult_processes(void)
{
  for(int i=0 ; i<NMULT ; i++) {
    pid_t pid = fork();
    
    if(pid < 0) {
      perror("fork");
      exit(EXIT_FAILURE);
    }

    if(pid == 0)
      mult_process(i);

  }
}

/*------------------------------------------------------------------*/

static void create_div_process(void)
{
    pid_t pid = fork();
    
    if(pid < 0) {
      perror("fork");
      exit(EXIT_FAILURE);
    }
    
    if(pid == 0)
      div_process();
    
}


/*------------------------------------------------------------------*/

static void wait_all_children(void)
{
  for(int i=0 ; i<(NADD + NMULT + 1) ; i++)
    wait(NULL);
}

/*------------------------------------------------------------------*/

static void print_results(void)
{
  printf("%d additionneurs, %d multiplicateurs, 1 diviseur, %d iterations\n", NADD, NMULT, NB_TOURS);
  printf("\n");
  printf("=====================================\n");
  printf("RESULTATS FINAUX\n");
  printf("=====================================\n");
  
  for(int i=0 ; i<NB_VAR ; i++) {
    printf("result[%d] = %ld",
	   i,
	   shared->result[i]);
    check(i)==shared->result[i]?printf(GREEN "\t- OK\n" RESET):printf(RED "\t- NOK\n" RESET);
  }

  printf("=====================================\n");

}

/*------------------------------------------------------------------*/

int main(void)
{
  setbuf(stdout, NULL);
  srand(getpid());

  if(shm_init_dijkstra(&shm,
		       sizeof(shared_data_t)) != 0)
    {
        perror("shm_init_dijkstra");
        exit(EXIT_FAILURE);
    }

  shared = (shared_data_t*)shm.ptr;

  init_shared_data();
  
  init_semaphores();
    
  create_add_processes();

  create_mult_processes();

  create_div_process();

  wait_all_children();

  print_results();

  destroy_semaphores();

  shm_destroy_dijkstra(&shm);

  return EXIT_SUCCESS;
}
