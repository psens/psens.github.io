/*
 * addmult_1_corrige.c.c
 *
 * Corrigé 1 valeur
 *
 * Synchronisation déterministe par variable.
 *
 * Chaque variable possède :
 *
 *   - son mutex
 *   - ses compteurs
 *   - ses barrières Add/Mult
 *
 */

#define _DEFAULT_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

#include "semaphore_dijkstra.h"

#define NADD      5
#define NMULT     5
#define NB_TOURS 8


#define RED   "\033[31m"
#define GREEN "\033[32m"
#define RESET "\033[0m"

/*------------------------------------------------------------------*/
/* Données partagées                                                */
/*------------------------------------------------------------------*/

typedef struct
{
    long result;

    int count;

} shared_data_t;

/*------------------------------------------------------------------*/

static dijkstra_shm_t shm;
static shared_data_t *shared;

  
/*
 * Definition des semaphores
 */


/*
 * A COMPLETER 
 */


/*------------------------------------------------------------------*/

static int calcul_add(int id)
{
    return id + 1;
}

static int calcul_mult()
{
    return 2;
}

static long check()
{ int k;
  int inc = NADD*(NADD+1)/2;
  long res = 0;

  for (k=0; k < NB_TOURS; k++) {
    res += inc;
    res *= 1<<NMULT;
  }
  return res; 
}


/*------------------------------------------------------------------*/
/* Processus Add                                                    */
/*------------------------------------------------------------------*/

void add_process(int id)
{

    for(int tour=0 ; tour<NB_TOURS; tour++)
    {

      /* A COMPLETER */
      
      /* Calcul local */

      int valeur = calcul_add(id);
	
      usleep(rand()%5000);
      
      /* Mise à jour variable partagée */
      
      shared->result += valeur;

      
    }
    
    exit(EXIT_SUCCESS);
}

/*------------------------------------------------------------------*/
/* Processus Mult                                                   */
/*------------------------------------------------------------------*/

void mult_process(int id)
{
  for(int tour=0 ; tour<NB_TOURS ; tour++) {

    /* A COMPLETER */
    
    /* Calcul local */
    int facteur = calcul_mult();
    usleep(rand()%5000);


    /* Mise à jour variable partagée */

    shared->result *= facteur;

  }

  exit(EXIT_SUCCESS);
}

/*------------------------------------------------------------------*/

static void init_shared_data(void)
{
  shared->result = 0;
  shared->count = 0;
}

/*------------------------------------------------------------------*/

static void init_semaphores(void)
{
  /* A COMPLETER */
    
}

/*------------------------------------------------------------------*/

static void destroy_semaphores(void)
{
  /* A COMPLETER */

}

/*------------------------------------------------------------------*/

static void create_add_processes(void)
{
  for(int i=0 ; i<NADD ; i++) {
    pid_t pid = fork();

    if(pid < 0) {
      perror("fork");
      exit(EXIT_FAILURE);
    }

    if(pid == 0)
      add_process(i);
  }
}

/*------------------------------------------------------------------*/

static void create_mult_processes(void)
{
  for(int i=0 ; i<NMULT ; i++) {
    pid_t pid = fork();
    
    if(pid < 0) {
      perror("fork");
      exit(EXIT_FAILURE);
    }

    if(pid == 0) 
      mult_process(i);
  }
}

/*------------------------------------------------------------------*/

static void wait_all_children(void)
{
    for(int i=0 ; i<(NADD + NMULT) ; i++)
      wait(NULL);
}

/*------------------------------------------------------------------*/

static void print_results(void)
{
  printf("%d additionneurs, %d multiplicateurs, %d iterations\n", NADD, NMULT, NB_TOURS);
  printf("\n");
  printf("=====================================\n");
  printf("RESULTAT FINAL\n");
  printf("=====================================\n");
  
  printf("result = %ld", shared->result);
  check()==shared->result?printf(GREEN "\t- OK\n" RESET):printf(RED "\t- NOK\n" RESET);
  
  printf("=====================================\n");

}

/*------------------------------------------------------------------*/

int main(void)
{
  setbuf(stdout, NULL);
    srand(getpid());

    if(shm_init_dijkstra(&shm,
                         sizeof(shared_data_t)) != 0)
    {
        perror("shm_init_dijkstra");
        exit(EXIT_FAILURE);
    }

    shared = (shared_data_t*)shm.ptr;

    init_shared_data();

    init_semaphores();

    create_add_processes();

    create_mult_processes();

    wait_all_children();

    print_results();

    destroy_semaphores();

    shm_destroy_dijkstra(&shm);

    return EXIT_SUCCESS;
}
