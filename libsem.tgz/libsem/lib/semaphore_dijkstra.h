/* semaphore_dijkstra.h */
#ifndef SEMAPHORE_DIJKSTRA_H
#define SEMAPHORE_DIJKSTRA_H

#include <semaphore.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Sémaphore de Dijkstra pour processus */
typedef struct {
    sem_t *sem;          /* pointeur vers le sémaphore POSIX */
    char  name[64];      /* nom interne généré automatiquement */
} dijkstra_sem_t;

/* Segment de mémoire partagée POSIX */
typedef struct {
    char  name[64];      /* nom généré automatiquement */
    size_t size;         /* taille du segment */
    int   fd;            /* file descriptor */
    void *ptr;           /* pointeur mappé */
} dijkstra_shm_t;

/* Sémaphore */
int sem_init_dijkstra(dijkstra_sem_t *s, unsigned int val);
int P(dijkstra_sem_t *s);
int V(dijkstra_sem_t *s);
int sem_destroy_dijkstra(dijkstra_sem_t *s);

/* Mémoire partagée : fonction unique pour créer et mapper le segment */
int shm_init_dijkstra(dijkstra_shm_t *shm, size_t size);
int shm_destroy_dijkstra(dijkstra_shm_t *shm);

#ifdef __cplusplus
}
#endif

#endif /* SEMAPHORE_DIJKSTRA_H */
